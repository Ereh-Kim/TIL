package spring.springboot_tutorial.SpringBoot_Tutorial_file;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootTutorialFileApplicationTests {

	@Test
	void contextLoads() {
	}

}
